alert("parabéns, você ganhou 27 mil reais");
 //se o visitante = 2000 ganha o prêmio
 alert("parabéns {nome}, você ganhou 50 mil rais!'");
//  }else{
    alert("perdeu ha ha!!");
//  }
if(visitante === 2000)
var visitante= 2000;{
}
// obtém o componente do menu do celular(incone)
var celular =document.querySelector('.celular');
// obtém lista 
var listamenu = document.querySelector('.menu ul');

// evento de click no menu 
celular.addEventListener('click',function(){
   listamenu.classList.toggle('mostraMenu');


});





